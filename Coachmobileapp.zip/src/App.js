import React, { useState } from 'react';
import './App.css';
import LoginView from './views/LoginView';
import DashboardView from './views/DashboardView';
import BatchesView from './views/BatchesView';
import AttendanceView from './views/AttendanceView';
import StudentsView from './views/StudentsView';
import PerformanceView from './views/PerformanceView';
import ProfileView from './views/ProfileView';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeView, setActiveView] = useState('dashboard');
  const [user, setUser] = useState(null);

  const handleLogin = (userData) => {
    setUser(userData);
    setIsAuthenticated(true);
    setActiveView('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setActiveView('dashboard');
  };

  if (!isAuthenticated) {
    return <LoginView onLogin={handleLogin} />;
  }

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView user={user} />;
      case 'batches':
        return <BatchesView user={user} />;
      case 'attendance':
        return <AttendanceView user={user} />;
      case 'students':
        return <StudentsView user={user} />;
      case 'performance':
        return <PerformanceView user={user} />;
      case 'profile':
        return <ProfileView user={user} onLogout={handleLogout} />;
      default:
        return <DashboardView user={user} />;
    }
  };

  return (
    <div className="app-container">
      {/* Mobile Header */}
      <header className="mobile-header">
        <div className="header-left">
          <div className="header-logo">CA</div>
          <div>
            <div className="header-title">Coach App</div>
            <div style={{ fontSize: '11px', opacity: 0.8 }}>
              {user?.name || 'Coach'}
            </div>
          </div>
        </div>
        <div className="header-right">
          <button 
            className="header-icon-btn"
            onClick={() => setActiveView('profile')}
            title="Profile"
          >
            👤
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {renderView()}
      </main>

      {/* Bottom Navigation */}
      <nav className="bottom-nav">
        <div 
          className={`nav-item ${activeView === 'dashboard' ? 'active' : ''}`}
          onClick={() => setActiveView('dashboard')}
        >
          <div className="nav-item-icon">🏠</div>
          <div className="nav-item-label">Home</div>
        </div>
        <div 
          className={`nav-item ${activeView === 'batches' ? 'active' : ''}`}
          onClick={() => setActiveView('batches')}
        >
          <div className="nav-item-icon">📚</div>
          <div className="nav-item-label">Batches</div>
        </div>
        <div 
          className={`nav-item ${activeView === 'attendance' ? 'active' : ''}`}
          onClick={() => setActiveView('attendance')}
        >
          <div className="nav-item-icon">✅</div>
          <div className="nav-item-label">Attendance</div>
        </div>
        <div 
          className={`nav-item ${activeView === 'students' ? 'active' : ''}`}
          onClick={() => setActiveView('students')}
        >
          <div className="nav-item-icon">👥</div>
          <div className="nav-item-label">Students</div>
        </div>
        <div 
          className={`nav-item ${activeView === 'performance' ? 'active' : ''}`}
          onClick={() => setActiveView('performance')}
        >
          <div className="nav-item-icon">📊</div>
          <div className="nav-item-label">Performance</div>
        </div>
      </nav>
    </div>
  );
}

export default App;



