import React, { useState } from 'react';

function PerformanceView({ user }) {
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [performanceData, setPerformanceData] = useState({});

  const batches = [
    { id: 1, name: 'Cricket U-10 Morning', students: 18 },
    { id: 2, name: 'Cricket U-14 Evening', students: 22 }
  ];

  const students = selectedBatch ? [
    { id: 1, name: 'Arjun Sharma' },
    { id: 2, name: 'Mia Verma' },
    { id: 3, name: 'Kabir Patel' },
    { id: 4, name: 'Sara Khan' }
  ] : [];

  const performanceMetrics = [
    { id: 'batting', label: 'Batting', max: 10 },
    { id: 'bowling', label: 'Bowling', max: 10 },
    { id: 'fielding', label: 'Fielding', max: 10 },
    { id: 'fitness', label: 'Fitness', max: 10 },
    { id: 'attitude', label: 'Attitude', max: 10 }
  ];

  const handleBatchSelect = (batch) => {
    setSelectedBatch(batch);
    setSelectedStudent(null);
    setPerformanceData({});
  };

  const handleStudentSelect = (student) => {
    setSelectedStudent(student);
    setPerformanceData({});
  };

  const handleScoreChange = (metricId, value) => {
    setPerformanceData(prev => ({
      ...prev,
      [metricId]: Math.min(Math.max(0, value), 10)
    }));
  };

  const handleSubmit = () => {
    const allFilled = performanceMetrics.every(m => performanceData[m.id] !== undefined);
    if (!allFilled) {
      alert('Please rate all performance metrics');
      return;
    }
    const avgScore = Object.values(performanceData).reduce((a, b) => a + b, 0) / performanceMetrics.length;
    alert(`Performance recorded for ${selectedStudent.name}!\n\nAverage Score: ${avgScore.toFixed(1)}/10`);
    setSelectedStudent(null);
    setPerformanceData({});
  };

  if (selectedStudent) {
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
          <button
            onClick={() => {
              setSelectedStudent(null);
              setPerformanceData({});
            }}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              border: '1px solid #e5e7eb',
              background: 'white',
              fontSize: '20px',
              cursor: 'pointer',
              marginRight: '12px'
            }}
          >
            ←
          </button>
          <div>
            <div style={{ fontSize: '18px', fontWeight: 700 }}>Record Performance</div>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>{selectedStudent.name}</div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Performance Metrics</div>
              <div className="card-subtitle">Rate each skill (0-10)</div>
            </div>
          </div>
          <div>
            {performanceMetrics.map((metric) => (
              <div key={metric.id} style={{ marginBottom: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <div style={{ fontSize: '14px', fontWeight: 600 }}>{metric.label}</div>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: '#89f436' }}>
                    {performanceData[metric.id] !== undefined ? `${performanceData[metric.id]}/10` : 'Not rated'}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((score) => (
                    <button
                      key={score}
                      onClick={() => handleScoreChange(metric.id, score)}
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '8px',
                        border: '1px solid #e5e7eb',
                        background: performanceData[metric.id] === score ? '#89f436' : 'white',
                        color: performanceData[metric.id] === score ? '#1a1a1a' : '#6b7280',
                        fontWeight: 600,
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                    >
                      {score}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="btn btn-primary btn-full"
          style={{ marginTop: '20px' }}
        >
          💾 Save Performance
        </button>
      </div>
    );
  }

  if (selectedBatch) {
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
          <button
            onClick={() => {
              setSelectedBatch(null);
              setSelectedStudent(null);
            }}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              border: '1px solid #e5e7eb',
              background: 'white',
              fontSize: '20px',
              cursor: 'pointer',
              marginRight: '12px'
            }}
          >
            ←
          </button>
          <div>
            <div style={{ fontSize: '18px', fontWeight: 700 }}>Select Student</div>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>{selectedBatch.name}</div>
          </div>
        </div>

        {students.map((student) => (
          <div
            key={student.id}
            className="card"
            style={{ cursor: 'pointer', marginBottom: '12px' }}
            onClick={() => handleStudentSelect(student)}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ 
                width: '48px', 
                height: '48px', 
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #89f43620 0%, #6bc42020 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '24px',
                flexShrink: 0
              }}>
                👤
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '16px', fontWeight: 700 }}>{student.name}</div>
              </div>
              <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: '20px' }}>
        <div className="card-header">
          <div>
            <div className="card-title">Record Performance</div>
            <div className="card-subtitle">Select a batch to record student performance</div>
          </div>
        </div>
      </div>

      {batches.map((batch) => (
        <div
          key={batch.id}
          className="card"
          style={{ cursor: 'pointer', marginBottom: '12px' }}
          onClick={() => handleBatchSelect(batch)}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: '16px', fontWeight: 700, marginBottom: '4px' }}>
                {batch.name}
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>
                {batch.students} students
              </div>
            </div>
            <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default PerformanceView;



