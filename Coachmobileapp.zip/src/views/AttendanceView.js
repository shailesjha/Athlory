import React, { useState } from 'react';

function AttendanceView({ user }) {
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [attendance, setAttendance] = useState({});

  const batches = [
    { id: 1, name: 'Cricket U-10 Morning', students: 18 },
    { id: 2, name: 'Cricket U-14 Evening', students: 22 },
    { id: 3, name: 'Football U-12', students: 16 }
  ];

  const mockStudents = selectedBatch ? [
    { id: 1, name: 'Arjun Sharma', present: attendance[1] || false },
    { id: 2, name: 'Mia Verma', present: attendance[2] || false },
    { id: 3, name: 'Kabir Patel', present: attendance[3] || false },
    { id: 4, name: 'Sara Khan', present: attendance[4] || false },
    { id: 5, name: 'Rohan Singh', present: attendance[5] || false }
  ] : [];

  const handleBatchSelect = (batch) => {
    setSelectedBatch(batch);
    setAttendance({});
  };

  const toggleAttendance = (studentId) => {
    setAttendance(prev => ({
      ...prev,
      [studentId]: !prev[studentId]
    }));
  };

  const presentCount = Object.values(attendance).filter(Boolean).length;
  const totalCount = mockStudents.length;

  const handleSubmit = () => {
    if (presentCount === 0) {
      alert('Please mark at least one student as present');
      return;
    }
    alert(`Attendance recorded!\n\nPresent: ${presentCount}/${totalCount}\nAbsent: ${totalCount - presentCount}`);
    setSelectedBatch(null);
    setAttendance({});
  };

  if (selectedBatch) {
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
          <button
            onClick={() => {
              setSelectedBatch(null);
              setAttendance({});
            }}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              border: '1px solid #e5e7eb',
              background: 'white',
              fontSize: '20px',
              cursor: 'pointer',
              marginRight: '12px'
            }}
          >
            ←
          </button>
          <div>
            <div style={{ fontSize: '18px', fontWeight: 700 }}>Take Attendance</div>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>{selectedBatch.name}</div>
          </div>
        </div>

        <div className="card" style={{ marginBottom: '16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Attendance Summary</div>
              <div style={{ fontSize: '24px', fontWeight: 700 }}>
                {presentCount} / {totalCount}
              </div>
            </div>
            <div style={{ 
              width: '80px', 
              height: '80px', 
              borderRadius: '50%',
              background: `conic-gradient(#89f436 ${(presentCount / totalCount) * 360}deg, #e5e7eb 0deg)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '14px',
              fontWeight: 700
            }}>
              {totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0}%
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Mark Attendance</div>
              <div className="card-subtitle">Tap to toggle present/absent</div>
            </div>
          </div>
          <div>
            {mockStudents.map((student) => (
              <div
                key={student.id}
                className="list-item"
                onClick={() => toggleAttendance(student.id)}
                style={{
                  background: student.present ? '#ecfdf5' : 'transparent'
                }}
              >
                <div style={{ 
                  width: '48px', 
                  height: '48px', 
                  borderRadius: '50%',
                  background: student.present ? '#10b981' : '#e5e7eb',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '20px',
                  marginRight: '12px',
                  flexShrink: 0
                }}>
                  {student.present ? '✓' : '○'}
                </div>
                <div className="list-item-content">
                  <div className="list-item-title">{student.name}</div>
                  <div className="list-item-subtitle">
                    {student.present ? 'Present' : 'Absent'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="btn btn-primary btn-full"
          style={{ marginTop: '20px' }}
        >
          ✅ Submit Attendance
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: '20px' }}>
        <div className="card-header">
          <div>
            <div className="card-title">Select Batch</div>
            <div className="card-subtitle">Choose a batch to mark attendance</div>
          </div>
        </div>
      </div>

      {batches.map((batch) => (
        <div
          key={batch.id}
          className="card"
          style={{ cursor: 'pointer' }}
          onClick={() => handleBatchSelect(batch)}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: '16px', fontWeight: 700, marginBottom: '4px' }}>
                {batch.name}
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>
                {batch.students} students
              </div>
            </div>
            <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default AttendanceView;



