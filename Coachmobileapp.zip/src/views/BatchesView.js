import React, { useState } from 'react';

function BatchesView({ user }) {
  const [selectedBatch, setSelectedBatch] = useState(null);

  const batches = [
    {
      id: 1,
      name: 'Cricket U-10 Morning',
      sport: 'Cricket',
      students: 18,
      maxStudents: 20,
      schedule: 'Mon, Wed, Fri - 06:00 to 07:00',
      venue: 'Main Ground',
      coach: 'Coach Arjun',
      nextSession: 'Today, 06:00 AM'
    },
    {
      id: 2,
      name: 'Cricket U-14 Evening',
      sport: 'Cricket',
      students: 22,
      maxStudents: 24,
      schedule: 'Mon, Wed, Fri - 17:00 to 18:30',
      venue: 'City Turf',
      coach: 'Coach Arjun',
      nextSession: 'Today, 05:00 PM'
    },
    {
      id: 3,
      name: 'Football U-12',
      sport: 'Football',
      students: 16,
      maxStudents: 18,
      schedule: 'Tue, Thu, Sat - 07:00 to 08:00',
      venue: 'Turf 1',
      coach: 'Coach Arjun',
      nextSession: 'Tomorrow, 07:00 AM'
    }
  ];

  const handleBatchClick = (batch) => {
    setSelectedBatch(batch);
  };

  if (selectedBatch) {
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
          <button
            onClick={() => setSelectedBatch(null)}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              border: '1px solid #e5e7eb',
              background: 'white',
              fontSize: '20px',
              cursor: 'pointer',
              marginRight: '12px'
            }}
          >
            ←
          </button>
          <div>
            <div style={{ fontSize: '18px', fontWeight: 700 }}>{selectedBatch.name}</div>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>{selectedBatch.sport}</div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Batch Details</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Schedule</div>
              <div style={{ fontSize: '14px', fontWeight: 600 }}>{selectedBatch.schedule}</div>
            </div>
            <div>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Venue</div>
              <div style={{ fontSize: '14px', fontWeight: 600 }}>{selectedBatch.venue}</div>
            </div>
            <div>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Students</div>
              <div style={{ fontSize: '14px', fontWeight: 600 }}>
                {selectedBatch.students} / {selectedBatch.maxStudents}
              </div>
              <div style={{ 
                width: '100%', 
                height: '8px', 
                background: '#e5e7eb', 
                borderRadius: '4px',
                marginTop: '8px',
                overflow: 'hidden'
              }}>
                <div style={{
                  width: `${(selectedBatch.students / selectedBatch.maxStudents) * 100}%`,
                  height: '100%',
                  background: 'linear-gradient(90deg, #89f436 0%, #6bc420 100%)',
                  transition: 'width 0.3s'
                }} />
              </div>
            </div>
            <div>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Next Session</div>
              <div style={{ fontSize: '14px', fontWeight: 600 }}>{selectedBatch.nextSession}</div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Quick Actions</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <button className="btn btn-primary btn-full">
              ✅ Take Attendance
            </button>
            <button className="btn btn-secondary btn-full">
              📊 Record Performance
            </button>
            <button className="btn btn-secondary btn-full">
              👥 View Students
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: '20px' }}>
        <div className="card-header">
          <div>
            <div className="card-title">My Batches</div>
            <div className="card-subtitle">{batches.length} batches assigned</div>
          </div>
        </div>
      </div>

      {batches.map((batch) => (
        <div key={batch.id} className="card" style={{ cursor: 'pointer' }} onClick={() => handleBatchClick(batch)}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
            <div style={{ 
              width: '56px', 
              height: '56px', 
              borderRadius: '12px',
              background: 'linear-gradient(135deg, #89f43620 0%, #6bc42020 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '24px',
              flexShrink: 0
            }}>
              {batch.sport === 'Cricket' ? '🏏' : '⚽'}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: '16px', fontWeight: 700, marginBottom: '4px' }}>
                {batch.name}
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>
                {batch.schedule}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                <span className="badge badge-info">
                  {batch.students} students
                </span>
                <span style={{ fontSize: '12px', color: '#6b7280' }}>
                  {batch.venue}
                </span>
              </div>
            </div>
            <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default BatchesView;



