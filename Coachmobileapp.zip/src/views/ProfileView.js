import React from 'react';

function ProfileView({ user, onLogout }) {
  return (
    <div>
      {/* Profile Header */}
      <div className="card" style={{ 
        background: 'linear-gradient(135deg, #89f436 0%, #6bc420 100%)',
        color: '#1a1a1a',
        marginBottom: '20px'
      }}>
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <div style={{
            width: '80px',
            height: '80px',
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.3)',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '36px',
            marginBottom: '16px'
          }}>
            👤
          </div>
          <div style={{ fontSize: '20px', fontWeight: 700, marginBottom: '4px' }}>
            {user?.name || 'Coach'}
          </div>
          <div style={{ fontSize: '14px', opacity: 0.8 }}>
            {user?.role || 'Head Coach'}
          </div>
        </div>
      </div>

      {/* Profile Info */}
      <div className="card" style={{ marginBottom: '16px' }}>
        <div className="card-header">
          <div>
            <div className="card-title">Profile Information</div>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Mobile Number</div>
            <div style={{ fontSize: '14px', fontWeight: 600 }}>{user?.mobile || '+91 98765 43210'}</div>
          </div>
          <div>
            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Email</div>
            <div style={{ fontSize: '14px', fontWeight: 600 }}>{user?.email || 'coach@athlory.com'}</div>
          </div>
          <div>
            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Role</div>
            <div style={{ fontSize: '14px', fontWeight: 600 }}>{user?.role || 'Head Coach'}</div>
          </div>
        </div>
      </div>

      {/* Settings */}
      <div className="card" style={{ marginBottom: '16px' }}>
        <div className="card-header">
          <div>
            <div className="card-title">Settings</div>
          </div>
        </div>
        <div>
          <div className="list-item">
            <div className="list-item-content">
              <div className="list-item-title">Notifications</div>
              <div className="list-item-subtitle">Manage notification preferences</div>
            </div>
            <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
          </div>
          <div className="list-item">
            <div className="list-item-content">
              <div className="list-item-title">Language</div>
              <div className="list-item-subtitle">English</div>
            </div>
            <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
          </div>
          <div className="list-item">
            <div className="list-item-content">
              <div className="list-item-title">About</div>
              <div className="list-item-subtitle">App version 1.0.0</div>
            </div>
            <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
          </div>
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={() => {
          if (window.confirm('Are you sure you want to logout?')) {
            onLogout();
          }
        }}
        className="btn btn-secondary btn-full"
        style={{ 
          background: '#fee2e2',
          color: '#dc2626',
          border: '1px solid #fecaca'
        }}
      >
        🚪 Logout
      </button>
    </div>
  );
}

export default ProfileView;



