import React, { useState } from 'react';

function StudentsView({ user }) {
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const batches = [
    { id: 1, name: 'Cricket U-10 Morning', count: 18 },
    { id: 2, name: 'Cricket U-14 Evening', count: 22 },
    { id: 3, name: 'Football U-12', count: 16 }
  ];

  const allStudents = [
    { id: 1, name: 'Arjun Sharma', batch: 'Cricket U-10 Morning', age: 10, attendance: 95, performance: 8.5 },
    { id: 2, name: 'Mia Verma', batch: 'Cricket U-10 Morning', age: 9, attendance: 88, performance: 7.8 },
    { id: 3, name: 'Kabir Patel', batch: 'Cricket U-14 Evening', age: 13, attendance: 92, performance: 9.2 },
    { id: 4, name: 'Sara Khan', batch: 'Football U-12', age: 11, attendance: 85, performance: 8.0 },
    { id: 5, name: 'Rohan Singh', batch: 'Cricket U-10 Morning', age: 10, attendance: 90, performance: 8.3 }
  ];

  const filteredStudents = selectedBatch
    ? allStudents.filter(s => s.batch === selectedBatch.name)
    : allStudents.filter(s => 
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.batch.toLowerCase().includes(searchTerm.toLowerCase())
      );

  const handleStudentClick = (student) => {
    // In real app, navigate to student detail page
    alert(`Student Details:\n\nName: ${student.name}\nBatch: ${student.batch}\nAge: ${student.age}\nAttendance: ${student.attendance}%\nPerformance: ${student.performance}/10`);
  };

  return (
    <div>
      {/* Search Bar */}
      <div className="card" style={{ marginBottom: '16px' }}>
        <input
          type="text"
          className="input"
          placeholder="🔍 Search students..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Batch Filter */}
      <div style={{ 
        display: 'flex', 
        gap: '8px', 
        marginBottom: '16px',
        overflowX: 'auto',
        paddingBottom: '4px',
        WebkitOverflowScrolling: 'touch'
      }}>
        <button
          onClick={() => setSelectedBatch(null)}
          className={`btn ${!selectedBatch ? 'btn-primary' : 'btn-secondary'}`}
          style={{ 
            whiteSpace: 'nowrap',
            fontSize: '12px',
            padding: '8px 16px'
          }}
        >
          All Students
        </button>
        {batches.map((batch) => (
          <button
            key={batch.id}
            onClick={() => setSelectedBatch(batch)}
            className={`btn ${selectedBatch?.id === batch.id ? 'btn-primary' : 'btn-secondary'}`}
            style={{ 
              whiteSpace: 'nowrap',
              fontSize: '12px',
              padding: '8px 16px'
            }}
          >
            {batch.name}
          </button>
        ))}
      </div>

      {/* Students List */}
      {filteredStudents.length > 0 ? (
        <div>
          {filteredStudents.map((student) => (
            <div
              key={student.id}
              className="card"
              style={{ cursor: 'pointer', marginBottom: '12px' }}
              onClick={() => handleStudentClick(student)}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ 
                  width: '56px', 
                  height: '56px', 
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg, #89f43620 0%, #6bc42020 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '24px',
                  flexShrink: 0
                }}>
                  👤
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: '16px', fontWeight: 700, marginBottom: '4px' }}>
                    {student.name}
                  </div>
                  <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>
                    {student.batch} • Age {student.age}
                  </div>
                  <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                    <span className="badge badge-success">
                      📊 {student.attendance}% attendance
                    </span>
                    <span className="badge badge-info">
                      ⭐ {student.performance}/10
                    </span>
                  </div>
                </div>
                <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card">
          <div className="empty-state">
            <div className="empty-state-icon">👥</div>
            <div className="empty-state-text">
              {searchTerm ? 'No students found' : 'No students in this batch'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default StudentsView;



