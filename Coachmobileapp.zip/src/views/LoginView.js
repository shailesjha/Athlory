import React, { useState } from 'react';

function LoginView({ onLogin }) {
  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [loginMethod, setLoginMethod] = useState('password'); // 'password' or 'otp'
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handlePasswordLogin = (e) => {
    e.preventDefault();
    if (!mobileNumber || !password) {
      alert('Please enter mobile number and password');
      return;
    }
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      onLogin({
        id: 1,
        name: 'Coach Arjun',
        role: 'Head Coach',
        mobile: mobileNumber,
        email: 'arjun@athlory.com'
      });
      setLoading(false);
    }, 500);
  };

  const handleOTPLogin = (e) => {
    e.preventDefault();
    if (!otpSent) {
      // Send OTP
      if (!mobileNumber || mobileNumber.length < 10) {
        alert('Please enter a valid mobile number');
        return;
      }
      setOtpSent(true);
      alert(`OTP sent to ${mobileNumber}\n\nFor demo: Use any 6-digit number`);
    } else {
      // Verify OTP
      if (!otp || otp.length !== 6) {
        alert('Please enter a valid 6-digit OTP');
        return;
      }
      setLoading(true);
      setTimeout(() => {
        onLogin({
          id: 1,
          name: 'Coach Arjun',
          role: 'Head Coach',
          mobile: mobileNumber,
          email: 'arjun@athlory.com'
        });
        setLoading(false);
      }, 500);
    }
  };

  const handleGoogleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      onLogin({
        id: 1,
        name: 'Coach Arjun',
        role: 'Head Coach',
        mobile: '+91 98765 43210',
        email: 'arjun@athlory.com'
      });
      setLoading(false);
    }, 500);
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column',
      justifyContent: 'center',
      padding: '20px',
      background: 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
    }}>
      <div style={{ 
        background: 'white', 
        borderRadius: '24px', 
        padding: '32px 24px',
        boxShadow: '0 8px 32px rgba(0,0,0,0.2)'
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '16px',
            background: 'linear-gradient(135deg, #89f436 0%, #6bc420 100%)',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '28px',
            fontWeight: 700,
            color: '#1a1a1a',
            marginBottom: '16px'
          }}>
            CA
          </div>
          <h1 style={{ fontSize: '24px', fontWeight: 700, marginBottom: '8px' }}>
            Welcome to <span style={{ color: '#89f436' }}>Athlory</span>
          </h1>
          <p style={{ fontSize: '14px', color: '#6b7280' }}>
            Coach & Admin Portal
          </p>
        </div>

        {/* Login Tabs */}
        <div style={{ 
          display: 'flex', 
          gap: '8px', 
          marginBottom: '24px',
          background: '#f8fafc',
          padding: '4px',
          borderRadius: '12px'
        }}>
          <button
            onClick={() => {
              setLoginMethod('password');
              setOtpSent(false);
              setOtp('');
            }}
            style={{
              flex: 1,
              padding: '10px',
              borderRadius: '8px',
              border: 'none',
              background: loginMethod === 'password' ? 'white' : 'transparent',
              fontWeight: loginMethod === 'password' ? 600 : 400,
              cursor: 'pointer',
              fontSize: '14px',
              boxShadow: loginMethod === 'password' ? '0 2px 4px rgba(0,0,0,0.1)' : 'none'
            }}
          >
            Password
          </button>
          <button
            onClick={() => {
              setLoginMethod('otp');
              setOtpSent(false);
              setOtp('');
            }}
            style={{
              flex: 1,
              padding: '10px',
              borderRadius: '8px',
              border: 'none',
              background: loginMethod === 'otp' ? 'white' : 'transparent',
              fontWeight: loginMethod === 'otp' ? 600 : 400,
              cursor: 'pointer',
              fontSize: '14px',
              boxShadow: loginMethod === 'otp' ? '0 2px 4px rgba(0,0,0,0.1)' : 'none'
            }}
          >
            OTP
          </button>
        </div>

        {/* Login Form */}
        <form onSubmit={loginMethod === 'password' ? handlePasswordLogin : handleOTPLogin}>
          <div className="input-group">
            <label className="input-label">Mobile Number</label>
            <input
              type="tel"
              className="input"
              placeholder="+91 98765 43210"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
              disabled={otpSent}
            />
          </div>

          {loginMethod === 'password' ? (
            <div className="input-group">
              <label className="input-label">Password</label>
              <input
                type="password"
                className="input"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          ) : (
            otpSent && (
              <div className="input-group">
                <label className="input-label">Enter OTP</label>
                <input
                  type="text"
                  className="input"
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  maxLength={6}
                />
                <button
                  type="button"
                  onClick={() => {
                    setOtpSent(false);
                    setOtp('');
                  }}
                  style={{
                    marginTop: '8px',
                    fontSize: '12px',
                    color: '#3b82f6',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer'
                  }}
                >
                  Resend OTP
                </button>
              </div>
            )
          )}

          <button
            type="submit"
            className="btn btn-primary btn-full"
            disabled={loading}
            style={{ marginTop: '8px' }}
          >
            {loading ? 'Logging in...' : (otpSent ? 'Verify & Login' : 'Login')}
          </button>
        </form>

        {/* Google Login */}
        <div style={{ marginTop: '24px', textAlign: 'center' }}>
          <div style={{ 
            fontSize: '12px', 
            color: '#6b7280', 
            marginBottom: '12px' 
          }}>
            OR
          </div>
          <button
            onClick={handleGoogleLogin}
            className="btn btn-secondary btn-full"
            disabled={loading}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
          >
            <span>🔍</span>
            Sign in with Google
          </button>
        </div>
      </div>
    </div>
  );
}

export default LoginView;



