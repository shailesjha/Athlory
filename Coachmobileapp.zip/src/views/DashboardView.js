import React from 'react';

function DashboardView({ user }) {
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  
  const mockStats = {
    totalBatches: 3,
    totalStudents: 45,
    todaySessions: 2,
    attendanceRate: 92
  };

  const upcomingSessions = [
    {
      id: 1,
      batch: 'Cricket U-10 Morning',
      time: '06:00 - 07:00',
      venue: 'Main Ground',
      students: 18
    },
    {
      id: 2,
      batch: 'Cricket U-14 Evening',
      time: '17:00 - 18:30',
      venue: 'City Turf',
      students: 22
    }
  ];

  const recentActivities = [
    { id: 1, type: 'attendance', text: 'Marked attendance for Cricket U-10', time: '2 hours ago' },
    { id: 2, type: 'performance', text: 'Recorded performance for 5 students', time: '5 hours ago' },
    { id: 3, type: 'session', text: 'Completed training session', time: 'Yesterday' }
  ];

  return (
    <div>
      {/* Welcome Card */}
      <div className="card" style={{ 
        background: 'linear-gradient(135deg, #89f436 0%, #6bc420 100%)',
        color: '#1a1a1a',
        marginBottom: '20px'
      }}>
        <div style={{ fontSize: '14px', fontWeight: 600, marginBottom: '8px' }}>
          Good {new Date().getHours() < 12 ? 'Morning' : new Date().getHours() < 18 ? 'Afternoon' : 'Evening'}!
        </div>
        <div style={{ fontSize: '20px', fontWeight: 700 }}>
          {user?.name || 'Coach'}
        </div>
        <div style={{ fontSize: '12px', marginTop: '4px', opacity: 0.8 }}>
          {today}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">{mockStats.totalBatches}</div>
          <div className="stat-label">Assigned Batches</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{mockStats.totalStudents}</div>
          <div className="stat-label">Total Students</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{mockStats.todaySessions}</div>
          <div className="stat-label">Today's Sessions</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{mockStats.attendanceRate}%</div>
          <div className="stat-label">Attendance Rate</div>
        </div>
      </div>

      {/* Today's Sessions */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Today's Sessions</div>
            <div className="card-subtitle">Upcoming training sessions</div>
          </div>
        </div>
        {upcomingSessions.length > 0 ? (
          <div>
            {upcomingSessions.map((session) => (
              <div key={session.id} className="list-item">
                <div style={{ 
                  width: '48px', 
                  height: '48px', 
                  borderRadius: '12px',
                  background: 'linear-gradient(135deg, #89f43620 0%, #6bc42020 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '20px',
                  marginRight: '12px'
                }}>
                  ⏰
                </div>
                <div className="list-item-content">
                  <div className="list-item-title">{session.batch}</div>
                  <div className="list-item-subtitle">
                    {session.time} • {session.venue} • {session.students} students
                  </div>
                </div>
                <div style={{ fontSize: '20px', color: '#6b7280' }}>→</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-state-icon">📅</div>
            <div className="empty-state-text">No sessions scheduled for today</div>
          </div>
        )}
      </div>

      {/* Recent Activities */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Recent Activities</div>
            <div className="card-subtitle">Your latest actions</div>
          </div>
        </div>
        {recentActivities.length > 0 ? (
          <div>
            {recentActivities.map((activity) => (
              <div key={activity.id} className="list-item">
                <div style={{ 
                  width: '40px', 
                  height: '40px', 
                  borderRadius: '50%',
                  background: '#f8fafc',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '18px',
                  marginRight: '12px'
                }}>
                  {activity.type === 'attendance' ? '✅' : activity.type === 'performance' ? '📊' : '🏋️'}
                </div>
                <div className="list-item-content">
                  <div className="list-item-title">{activity.text}</div>
                  <div className="list-item-subtitle">{activity.time}</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-state-icon">📝</div>
            <div className="empty-state-text">No recent activities</div>
          </div>
        )}
      </div>
    </div>
  );
}

export default DashboardView;



