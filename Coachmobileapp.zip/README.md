# Coach Mobile App

Mobile application for coaches and admins to manage batches, attendance, and student performance.

## Features

- **Login**: Password, OTP, or Google login
- **Dashboard**: Overview of batches, sessions, and activities
- **Batches**: View assigned batches and batch details
- **Attendance**: Mark attendance for students
- **Students**: View student information and performance
- **Performance**: Record student training performance
- **Profile**: View profile and settings

## Setup

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

3. Open [http://localhost:3001](http://localhost:3001) to view it in the browser.

**Note**: This app runs on port 3001 to avoid conflicts with the academy-admin app (port 3000).

## Mobile-First Design

The app is designed with a mobile-first approach and includes:
- Bottom navigation bar
- Touch-friendly interface
- Responsive cards and layouts
- Mobile-optimized modals

## Project Structure

```
src/
  ├── App.js              # Main app component with navigation
  ├── App.css             # Main styles
  ├── index.js            # Entry point
  ├── index.css           # Global styles
  └── views/              # View components
      ├── LoginView.js
      ├── DashboardView.js
      ├── BatchesView.js
      ├── AttendanceView.js
      ├── StudentsView.js
      ├── PerformanceView.js
      └── ProfileView.js
```

